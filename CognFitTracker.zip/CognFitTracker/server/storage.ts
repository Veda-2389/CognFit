import { 
  User, InsertUser, 
  StudySession, InsertStudySession,
  ProcessFitnessActivity, InsertProcessFitnessActivity,
  YogaSession, InsertYogaSession,
  ActivityCompletion, InsertActivityCompletion,
  UserSettings, InsertUserSettings
} from "@shared/schema";

import session from "express-session";
import createMemoryStore from "memorystore";
import { addDays, startOfWeek, endOfWeek, formatISO, subDays, parseISO } from "date-fns";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store
  sessionStore: session.SessionStore;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Study sessions
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  getStudySessionsByUserId(userId: number): Promise<StudySession[]>;
  
  // Process fitness activities
  getAllProcessFitnessActivities(): Promise<ProcessFitnessActivity[]>;
  getProcessFitnessActivityById(id: number): Promise<ProcessFitnessActivity | undefined>;
  
  // Yoga sessions
  getAllYogaSessions(): Promise<YogaSession[]>;
  getYogaSessionById(id: number): Promise<YogaSession | undefined>;
  
  // Activity completions
  createActivityCompletion(completion: InsertActivityCompletion): Promise<ActivityCompletion>;
  getActivityCompletionsByUserId(userId: number): Promise<ActivityCompletion[]>;
  
  // User settings
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  updateUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  
  // Analytics & stats
  getUserStats(userId: number): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private studySessions: Map<number, StudySession>;
  private processFitnessActivities: Map<number, ProcessFitnessActivity>;
  private yogaSessions: Map<number, YogaSession>;
  private activityCompletions: Map<number, ActivityCompletion>;
  private userSettings: Map<number, UserSettings>;
  
  sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private studySessionIdCounter: number;
  private processActivityIdCounter: number;
  private yogaSessionIdCounter: number;
  private activityCompletionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.studySessions = new Map();
    this.processFitnessActivities = new Map();
    this.yogaSessions = new Map();
    this.activityCompletions = new Map();
    this.userSettings = new Map();
    
    this.userIdCounter = 1;
    this.studySessionIdCounter = 1;
    this.processActivityIdCounter = 1;
    this.yogaSessionIdCounter = 1;
    this.activityCompletionIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h in ms
    });
    
    // Seed some initial data
    this.seedInitialData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    
    // Create default user settings
    await this.updateUserSettings({
      userId: id,
      studyGoalHours: 10,
      emailNotifications: true,
      theme: "light"
    });
    
    return user;
  }

  // Study sessions
  async createStudySession(session: InsertStudySession): Promise<StudySession> {
    const id = this.studySessionIdCounter++;
    const studySession: StudySession = { ...session, id };
    this.studySessions.set(id, studySession);
    return studySession;
  }

  async getStudySessionsByUserId(userId: number): Promise<StudySession[]> {
    return Array.from(this.studySessions.values()).filter(
      (session) => session.userId === userId
    );
  }

  // Process fitness activities
  async getAllProcessFitnessActivities(): Promise<ProcessFitnessActivity[]> {
    return Array.from(this.processFitnessActivities.values());
  }

  async getProcessFitnessActivityById(id: number): Promise<ProcessFitnessActivity | undefined> {
    return this.processFitnessActivities.get(id);
  }

  // Yoga sessions
  async getAllYogaSessions(): Promise<YogaSession[]> {
    return Array.from(this.yogaSessions.values());
  }

  async getYogaSessionById(id: number): Promise<YogaSession | undefined> {
    return this.yogaSessions.get(id);
  }

  // Activity completions
  async createActivityCompletion(completion: InsertActivityCompletion): Promise<ActivityCompletion> {
    const id = this.activityCompletionIdCounter++;
    const activityCompletion: ActivityCompletion = { 
      ...completion, 
      id, 
      completedAt: new Date()
    };
    this.activityCompletions.set(id, activityCompletion);
    return activityCompletion;
  }

  async getActivityCompletionsByUserId(userId: number): Promise<ActivityCompletion[]> {
    return Array.from(this.activityCompletions.values()).filter(
      (completion) => completion.userId === userId
    );
  }

  // User settings
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    return this.userSettings.get(userId);
  }

  async updateUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const existingSettings = this.userSettings.get(settings.userId);
    const updatedSettings: UserSettings = { 
      ...existingSettings,
      ...settings
    };
    this.userSettings.set(settings.userId, updatedSettings);
    return updatedSettings;
  }

  // Analytics and statistics
  async getUserStats(userId: number): Promise<any> {
    const now = new Date();
    const currentWeekStart = startOfWeek(now);
    const currentWeekEnd = endOfWeek(now);
    const lastWeekStart = startOfWeek(subDays(now, 7));
    const lastWeekEnd = endOfWeek(subDays(now, 7));
    
    // Get study sessions for current week
    const allStudySessions = await this.getStudySessionsByUserId(userId);
    const currentWeekStudySessions = allStudySessions.filter(session => {
      const sessionDate = new Date(session.date);
      return sessionDate >= currentWeekStart && sessionDate <= currentWeekEnd;
    });
    
    // Get study sessions for last week
    const lastWeekStudySessions = allStudySessions.filter(session => {
      const sessionDate = new Date(session.date);
      return sessionDate >= lastWeekStart && sessionDate <= lastWeekEnd;
    });
    
    // Calculate weekly study hours
    const currentWeekStudyMinutes = currentWeekStudySessions.reduce(
      (total, session) => total + session.duration, 0
    );
    const lastWeekStudyMinutes = lastWeekStudySessions.reduce(
      (total, session) => total + session.duration, 0
    );
    
    const weeklyStudyHours = (currentWeekStudyMinutes / 60).toFixed(1);
    
    // Calculate percentage change
    let weeklyStudyIncrease = 0;
    if (lastWeekStudyMinutes > 0) {
      weeklyStudyIncrease = Math.round(
        ((currentWeekStudyMinutes - lastWeekStudyMinutes) / lastWeekStudyMinutes) * 100
      );
    }
    
    // Get activity completions by type
    const allCompletions = await this.getActivityCompletionsByUserId(userId);
    const processFitnessCompletions = allCompletions.filter(
      completion => completion.activityType === 'process_fitness'
    );
    const yogaCompletions = allCompletions.filter(
      completion => completion.activityType === 'yoga'
    );
    
    // Get current week's yoga and process fitness completions
    const currentWeekYogaCompletions = yogaCompletions.filter(completion => {
      const completionDate = new Date(completion.completedAt);
      return completionDate >= currentWeekStart && completionDate <= currentWeekEnd;
    });
    
    const lastWeekYogaCompletions = yogaCompletions.filter(completion => {
      const completionDate = new Date(completion.completedAt);
      return completionDate >= lastWeekStart && completionDate <= lastWeekEnd;
    });
    
    // Calculate focus score (average of all focus scores from this week)
    const focusScores = allCompletions
      .filter(completion => completion.focusScore !== null && completion.focusScore !== undefined)
      .filter(completion => {
        const completionDate = new Date(completion.completedAt);
        return completionDate >= currentWeekStart && completionDate <= currentWeekEnd;
      })
      .map(completion => completion.focusScore);
    
    const averageFocusScore = focusScores.length > 0
      ? (focusScores.reduce((sum, score) => sum + (score || 0), 0) / focusScores.length).toFixed(1)
      : "0.0";
    
    // Get last 3 activity completions for recent activity
    const recentActivity = Array.from(allCompletions.values())
      .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime())
      .slice(0, 3);
    
    // Generate daily study data for the current week
    const dailyStudyData = [];
    for (let i = 0; i < 7; i++) {
      const day = addDays(currentWeekStart, i);
      const dayFormatted = formatISO(day, { representation: 'date' });
      
      const dayStudyMinutes = allStudySessions
        .filter(session => {
          const sessionDate = new Date(session.date);
          return formatISO(sessionDate, { representation: 'date' }) === dayFormatted;
        })
        .reduce((total, session) => total + session.duration, 0);
      
      dailyStudyData.push({
        day: day.toLocaleDateString('en-US', { weekday: 'short' }),
        minutes: dayStudyMinutes,
        hours: (dayStudyMinutes / 60).toFixed(1)
      });
    }
    
    // Get total process fitness activities for calculation
    const totalProcessFitnessActivities = await this.getAllProcessFitnessActivities();
    
    return {
      weeklyStudyHours,
      weeklyStudyIncrease: `${weeklyStudyIncrease}% from last week`,
      processCompleted: `${processFitnessCompletions.length}/${totalProcessFitnessActivities.length}`,
      processPercentage: `${Math.round((processFitnessCompletions.length / totalProcessFitnessActivities.length) * 100)}% completed`,
      yogaCompleted: currentWeekYogaCompletions.length,
      yogaIncrease: `${currentWeekYogaCompletions.length - lastWeekYogaCompletions.length} more than last week`,
      focusScore: `${averageFocusScore}/10`,
      focusImprovement: "Improving",
      dailyStudyData,
      recentActivity
    };
  }

  // Seed initial data for the application
  private seedInitialData() {
    // Seed process fitness activities
    const processFitnessActivities: InsertProcessFitnessActivity[] = [
      {
        title: "Deep Focus Techniques",
        description: "Learn techniques to improve concentration and focus during study sessions.",
        duration: 15,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Magnifying%20Glass%20Tilted%20Right.png",
        category: "Focus"
      },
      {
        title: "Active Recall Practice",
        description: "Master the art of active recall to improve memory retention and understanding.",
        duration: 20,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Light%20Bulb.png",
        category: "Memory"
      },
      {
        title: "Spaced Repetition System",
        description: "Create an effective spaced repetition system to retain information for the long term.",
        duration: 25,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Alarm%20Clock.png",
        category: "Memory"
      },
      {
        title: "Pomodoro Technique",
        description: "Implement the Pomodoro technique for better time management and productivity.",
        duration: 10,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Food/Tomato.png",
        category: "Productivity"
      },
      {
        title: "Cornell Note-Taking Method",
        description: "Master the Cornell method for effective note-taking during lectures and readings.",
        duration: 20,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Notebook.png",
        category: "Note-taking"
      },
      {
        title: "Mind Mapping for Concepts",
        description: "Use mind maps to connect complex concepts and improve understanding.",
        duration: 15,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Puzzle%20Piece.png",
        category: "Comprehension"
      },
      {
        title: "Feynman Technique",
        description: "Apply the Feynman technique to simplify complex topics and identify knowledge gaps.",
        duration: 30,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Smilies/Nerd%20Face.png",
        category: "Comprehension"
      },
      {
        title: "Interleaved Practice",
        description: "Implement interleaved practice to improve problem-solving skills across topics.",
        duration: 25,
        imageUrl: "https://cdn.jsdelivr.net/gh/Tarikul-Islam-Anik/Animated-Fluent-Emojis/Emojis/Objects/Abacus.png",
        category: "Problem Solving"
      }
    ];

    processFitnessActivities.forEach(activity => {
      const id = this.processActivityIdCounter++;
      this.processFitnessActivities.set(id, { ...activity, id });
    });

    // Seed yoga sessions
    const yogaSessions: InsertYogaSession[] = [
      {
        title: "Study Break Yoga",
        description: "A quick 10-minute yoga session to refresh your mind during study breaks.",
        duration: 10,
        videoUrl: "https://www.youtube.com/embed/sTANio_2E0Q",
        difficulty: "beginner"
      },
      {
        title: "Morning Energy Flow",
        description: "Start your day with this energizing yoga session to prepare for productive studying.",
        duration: 15,
        videoUrl: "https://www.youtube.com/embed/UEEsdXn8oG8",
        difficulty: "beginner"
      },
      {
        title: "Focus & Concentration Yoga",
        description: "Improve your focus and concentration with these targeted yoga poses.",
        duration: 20,
        videoUrl: "https://www.youtube.com/embed/k0PSUDvLi8E",
        difficulty: "intermediate"
      },
      {
        title: "Stress-Relief Yoga for Students",
        description: "Release exam stress and anxiety with this calming yoga session.",
        duration: 25,
        videoUrl: "https://www.youtube.com/embed/Nw2oBIrQGLo",
        difficulty: "beginner"
      },
      {
        title: "Brain Power Yoga",
        description: "Boost your cognitive function with poses that increase blood flow to the brain.",
        duration: 15,
        videoUrl: "https://www.youtube.com/embed/QHkXvPq2pQE",
        difficulty: "intermediate"
      }
    ];

    yogaSessions.forEach(session => {
      const id = this.yogaSessionIdCounter++;
      this.yogaSessions.set(id, { ...session, id });
    });
  }
}

export const storage = new MemStorage();
