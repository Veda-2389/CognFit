import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertStudySessionSchema, 
  insertActivityCompletionSchema,
  insertUserSettingsSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

// Middleware to check if the user is authenticated
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Study sessions routes
  app.get("/api/study-sessions", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const sessions = await storage.getStudySessionsByUserId(userId);
      res.json(sessions);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/study-sessions", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const data = insertStudySessionSchema.parse({
        ...req.body,
        userId
      });
      
      const session = await storage.createStudySession(data);
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Process fitness routes
  app.get("/api/process-fitness", async (req, res, next) => {
    try {
      const activities = await storage.getAllProcessFitnessActivities();
      res.json(activities);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/process-fitness/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const activity = await storage.getProcessFitnessActivityById(id);
      
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      res.json(activity);
    } catch (error) {
      next(error);
    }
  });

  // Yoga sessions routes
  app.get("/api/yoga-sessions", async (req, res, next) => {
    try {
      const sessions = await storage.getAllYogaSessions();
      res.json(sessions);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/yoga-sessions/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.getYogaSessionById(id);
      
      if (!session) {
        return res.status(404).json({ message: "Yoga session not found" });
      }
      
      res.json(session);
    } catch (error) {
      next(error);
    }
  });

  // Activity completions routes
  app.post("/api/activity-completions", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const data = insertActivityCompletionSchema.parse({
        ...req.body,
        userId
      });
      
      const completion = await storage.createActivityCompletion(data);
      res.status(201).json(completion);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  app.get("/api/activity-completions", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const completions = await storage.getActivityCompletionsByUserId(userId);
      res.json(completions);
    } catch (error) {
      next(error);
    }
  });

  // User settings routes
  app.get("/api/user-settings", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const settings = await storage.getUserSettings(userId);
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/user-settings", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const data = insertUserSettingsSchema.parse({
        ...req.body,
        userId
      });
      
      const settings = await storage.updateUserSettings(data);
      res.json(settings);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Stats API for dashboard
  app.get("/api/stats", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
