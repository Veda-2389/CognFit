import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
});

// Study session schema
export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  duration: integer("duration").notNull(), // in minutes
  description: text("description"),
});

export const insertStudySessionSchema = createInsertSchema(studySessions).pick({
  userId: true,
  date: true,
  duration: true,
  description: true,
});

// Process fitness activities
export const processFitnessActivities = pgTable("process_fitness_activities", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in minutes
  imageUrl: text("image_url"),
  category: text("category").notNull(),
});

export const insertProcessFitnessActivitySchema = createInsertSchema(processFitnessActivities).pick({
  title: true,
  description: true,
  duration: true,
  imageUrl: true,
  category: true,
});

// Yoga sessions
export const yogaSessions = pgTable("yoga_sessions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in minutes
  videoUrl: text("video_url").notNull(),
  difficulty: text("difficulty").notNull(), // beginner, intermediate, advanced
});

export const insertYogaSessionSchema = createInsertSchema(yogaSessions).pick({
  title: true,
  description: true,
  duration: true,
  videoUrl: true,
  difficulty: true,
});

// Activity completions (to track user progress)
export const activityCompletions = pgTable("activity_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  activityType: text("activity_type").notNull(), // 'yoga', 'process_fitness', 'study_session'
  activityId: integer("activity_id").notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
  rating: integer("rating"), // user's rating of the activity (optional)
  focusScore: real("focus_score"), // user's self-reported focus score (optional)
  status: text("status").notNull().default("completed"), // completed, in_progress
});

export const insertActivityCompletionSchema = createInsertSchema(activityCompletions).pick({
  userId: true,
  activityType: true,
  activityId: true,
  rating: true,
  focusScore: true,
  status: true,
});

// User settings
export const userSettings = pgTable("user_settings", {
  userId: integer("user_id").primaryKey(),
  studyGoalHours: integer("study_goal_hours").default(10), // weekly study goal in hours
  emailNotifications: boolean("email_notifications").default(true),
  theme: text("theme").default("light"),
});

export const insertUserSettingsSchema = createInsertSchema(userSettings);

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type ProcessFitnessActivity = typeof processFitnessActivities.$inferSelect;
export type InsertProcessFitnessActivity = z.infer<typeof insertProcessFitnessActivitySchema>;

export type YogaSession = typeof yogaSessions.$inferSelect;
export type InsertYogaSession = z.infer<typeof insertYogaSessionSchema>;

export type ActivityCompletion = typeof activityCompletions.$inferSelect;
export type InsertActivityCompletion = z.infer<typeof insertActivityCompletionSchema>;

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
