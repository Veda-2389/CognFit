import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Activity,
  HeartPulse,
  BarChart2,
  Settings,
  LogOut
} from "lucide-react";
import { Button } from "./button";
import { Avatar, AvatarFallback } from "./avatar";
import { Logo } from "./logo";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const navItems = [
    { name: "Dashboard", path: "/", icon: <LayoutDashboard className="w-5 h-5 mr-3" /> },
    { name: "Process Fitness", path: "/process-fitness", icon: <HeartPulse className="w-5 h-5 mr-3" /> },
    { name: "Yoga Sessions", path: "/yoga-sessions", icon: <Activity className="w-5 h-5 mr-3" /> },
    { name: "Progress Analytics", path: "/progress-analytics", icon: <BarChart2 className="w-5 h-5 mr-3" /> },
    { name: "Settings", path: "/settings", icon: <Settings className="w-5 h-5 mr-3" /> },
  ];
  
  const getUserInitials = () => {
    if (!user) return "U";
    
    if (user.fullName) {
      const nameParts = user.fullName.split(" ");
      if (nameParts.length >= 2) {
        return `${nameParts[0][0]}${nameParts[1][0]}`;
      }
      return user.fullName[0];
    }
    
    return user.username[0];
  };

  return (
    <div className="bg-white w-64 flex-shrink-0 border-r border-neutral-200 hidden md:flex md:flex-col h-screen fixed">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-4 border-b border-neutral-200">
          <div className="flex items-center">
            <Logo size="small" />
            <h1 className="ml-3 text-xl font-semibold text-gray-900">CognFit</h1>
          </div>
        </div>
        
        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto py-4">
          <div className="px-2 space-y-1">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <a
                  className={cn(
                    "group flex items-center px-2 py-3 text-sm font-medium rounded-md",
                    location === item.path
                      ? "bg-primary/10 text-primary border-l-4 border-primary pl-1"
                      : "text-neutral-500 hover:bg-neutral-100"
                  )}
                >
                  {item.icon}
                  {item.name}
                </a>
              </Link>
            ))}
          </div>
        </nav>
        
        {/* User Profile */}
        <div className="border-t border-neutral-200 p-4">
          <div className="flex items-center">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-900">{user?.fullName || user?.username}</p>
              <p className="text-xs font-medium text-neutral-500">{user?.username}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="ml-auto text-neutral-500 hover:text-neutral-700"
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
