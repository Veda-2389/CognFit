import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import {
  Menu,
  X,
  LayoutDashboard,
  Activity,
  HeartPulse,
  BarChart2,
  Settings,
  LogOut
} from "lucide-react";
import { Button } from "./button";
import { Avatar, AvatarFallback } from "./avatar";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "./sheet";
import { Logo } from "./logo";

export function MobileHeader({ title }: { title: string }) {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
    setOpen(false);
  };
  
  const navItems = [
    { name: "Dashboard", path: "/", icon: <LayoutDashboard className="w-5 h-5 mr-3" /> },
    { name: "Process Fitness", path: "/process-fitness", icon: <HeartPulse className="w-5 h-5 mr-3" /> },
    { name: "Yoga Sessions", path: "/yoga-sessions", icon: <Activity className="w-5 h-5 mr-3" /> },
    { name: "Progress Analytics", path: "/progress-analytics", icon: <BarChart2 className="w-5 h-5 mr-3" /> },
    { name: "Settings", path: "/settings", icon: <Settings className="w-5 h-5 mr-3" /> },
  ];
  
  const getUserInitials = () => {
    if (!user) return "U";
    
    if (user.fullName) {
      const nameParts = user.fullName.split(" ");
      if (nameParts.length >= 2) {
        return `${nameParts[0][0]}${nameParts[1][0]}`;
      }
      return user.fullName[0];
    }
    
    return user.username[0];
  };

  return (
    <>
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white z-10 border-b border-neutral-200">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Logo size="small" />
            <h1 className="ml-2 text-lg font-semibold text-gray-900">CognFit</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
        
        <div className="px-4 py-2 border-t border-neutral-200">
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
        </div>
      </div>
      
      {/* Mobile menu drawer */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="p-0 w-64">
          <SheetHeader className="p-4 border-b border-neutral-200">
            <div className="flex items-center">
              <Logo size="small" />
              <SheetTitle className="ml-2">CognFit</SheetTitle>
            </div>
          </SheetHeader>
          
          <div className="flex flex-col h-full">
            {/* Navigation */}
            <nav className="flex-1 overflow-y-auto py-4">
              <div className="px-2 space-y-1">
                {navItems.map((item) => (
                  <Link key={item.path} href={item.path}>
                    <a
                      className={cn(
                        "group flex items-center px-2 py-3 text-sm font-medium rounded-md",
                        location === item.path
                          ? "bg-primary/10 text-primary border-l-4 border-primary pl-1"
                          : "text-neutral-500 hover:bg-neutral-100"
                      )}
                      onClick={() => setOpen(false)}
                    >
                      {item.icon}
                      {item.name}
                    </a>
                  </Link>
                ))}
              </div>
            </nav>
            
            {/* User Profile */}
            <div className="border-t border-neutral-200 p-4">
              <div className="flex items-center">
                <Avatar>
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {getUserInitials()}
                  </AvatarFallback>
                </Avatar>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{user?.fullName || user?.username}</p>
                  <p className="text-xs font-medium text-neutral-500">{user?.username}</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="ml-auto text-neutral-500 hover:text-neutral-700"
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
      
      {/* Spacer to push content below fixed header on mobile */}
      <div className="h-[105px] md:h-0 md:hidden" />
    </>
  );
}
