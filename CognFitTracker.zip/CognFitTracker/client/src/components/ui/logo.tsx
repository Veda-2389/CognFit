import logoPath from '../../assets/CognFit.png';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  showTagline?: boolean;
}

export function Logo({ size = 'medium', showTagline = false }: LogoProps) {
  const sizeClasses = {
    small: 'h-8 w-8',
    medium: 'h-12 w-12',
    large: 'h-16 w-16'
  };

  return (
    <div className="flex flex-col items-center">
      <img 
        src={logoPath} 
        alt="CognFit Logo" 
        className={`${sizeClasses[size]} rounded-full object-cover`}
      />
      {showTagline && (
        <p className="text-xs font-medium mt-1 text-neutral-700">FOCUS. FIT. SUCCEED.</p>
      )}
    </div>
  );
}