import { Card, CardContent } from "@/components/ui/card";
import { ArrowUp, ArrowDown, Clock, Activity, Brain, Dumbbell } from "lucide-react";
import { cn } from "@/lib/utils";

type ProgressCardProps = {
  title: string;
  value: string;
  trend: string;
  trendType: "positive" | "negative" | "neutral";
  icon: string;
  color: "primary" | "secondary" | "accent";
};

export function ProgressCard({ title, value, trend, trendType, icon, color }: ProgressCardProps) {
  const getIconComponent = () => {
    switch (icon) {
      case "schedule":
        return <Clock className="h-6 w-6" />;
      case "fitness_center":
        return <Dumbbell className="h-6 w-6" />;
      case "self_improvement":
        return <Activity className="h-6 w-6" />;
      case "psychology":
        return <Brain className="h-6 w-6" />;
      default:
        return <Clock className="h-6 w-6" />;
    }
  };
  
  const getColorClass = () => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary";
      case "secondary":
        return "bg-amber-100 text-amber-700";
      case "accent":
        return "bg-cyan-100 text-cyan-700";
      default:
        return "bg-primary/10 text-primary";
    }
  };
  
  const getTrendIcon = () => {
    if (trendType === "positive") {
      return <ArrowUp className="h-4 w-4 mr-1 text-green-600" />;
    } else if (trendType === "negative") {
      return <ArrowDown className="h-4 w-4 mr-1 text-red-600" />;
    }
    return null;
  };
  
  const getTrendColorClass = () => {
    if (trendType === "positive") {
      return "text-green-600";
    } else if (trendType === "negative") {
      return "text-red-600";
    }
    return "text-neutral-500";
  };

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-neutral-500 text-sm font-medium">{title}</p>
            <p className="text-2xl font-bold mt-1 text-gray-900">{value}</p>
            <p className={cn("text-sm flex items-center mt-1", getTrendColorClass())}>
              {getTrendIcon()}
              <span>{trend}</span>
            </p>
          </div>
          <div className={cn("w-12 h-12 rounded-full flex items-center justify-center", getColorClass())}>
            {getIconComponent()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
