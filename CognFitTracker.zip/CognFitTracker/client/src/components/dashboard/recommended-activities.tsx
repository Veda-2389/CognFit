import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight, Brain, Activity, Dumbbell } from "lucide-react";

type RecommendedActivitiesProps = {
  isLoading: boolean;
};

export function RecommendedActivities({ isLoading }: RecommendedActivitiesProps) {
  const { data: processFitness } = useQuery({
    queryKey: ["/api/process-fitness"],
    enabled: !isLoading,
  });

  const { data: yogaSessions } = useQuery({
    queryKey: ["/api/yoga-sessions"],
    enabled: !isLoading,
  });

  // Select 3 random activities for recommendations (2 process fitness, 1 yoga)
  const getRecommendedActivities = () => {
    const recommended = [];
    
    if (processFitness && processFitness.length > 0) {
      // Get two random process fitness activities
      const shuffledProcess = [...processFitness].sort(() => 0.5 - Math.random());
      recommended.push(...shuffledProcess.slice(0, 2).map(activity => ({
        ...activity,
        type: "process_fitness",
        url: `/process-fitness`
      })));
    }
    
    if (yogaSessions && yogaSessions.length > 0) {
      // Get one random yoga session
      const randomYoga = yogaSessions[Math.floor(Math.random() * yogaSessions.length)];
      recommended.push({
        ...randomYoga,
        type: "yoga",
        url: `/yoga-sessions`
      });
    }
    
    return recommended;
  };

  const recommendedActivities = getRecommendedActivities();

  const getIcon = (type: string) => {
    switch (type) {
      case "process_fitness":
        return <Brain className="h-5 w-5 text-white" />;
      case "yoga":
        return <Activity className="h-5 w-5 text-white" />;
      default:
        return <Brain className="h-5 w-5 text-white" />;
    }
  };

  const getBgColor = (type: string, index: number) => {
    if (type === "process_fitness") {
      return index % 2 === 0 ? "bg-primary" : "bg-amber-500";
    } else {
      return "bg-cyan-500";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">Recommended For You</CardTitle>
      </CardHeader>
      <CardContent className="px-0 pb-0">
        {isLoading ? (
          <div className="space-y-4 px-6">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : (
          <div className="space-y-1">
            {recommendedActivities.map((activity, index) => (
              <Link
                key={`${activity.type}-${activity.id}`}
                href={activity.url}
              >
                <a className="flex items-center p-4 hover:bg-neutral-50 transition-colors cursor-pointer">
                  <div className={`w-10 h-10 rounded-full ${getBgColor(activity.type, index)} flex items-center justify-center mr-4`}>
                    {getIcon(activity.type)}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">{activity.title}</h4>
                    <p className="text-xs text-neutral-500">
                      {activity.duration} min • {activity.type === "process_fitness" ? "Process Fitness" : "Yoga Session"}
                    </p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-neutral-400" />
                </a>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
