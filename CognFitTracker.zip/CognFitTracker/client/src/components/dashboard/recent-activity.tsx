import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Brain, Activity, Clock, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";

type RecentActivityProps = {
  activities: any[];
  isLoading: boolean;
};

export function RecentActivity({ activities, isLoading }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "process_fitness":
        return <Brain className="h-4 w-4 text-white" />;
      case "yoga":
        return <Activity className="h-4 w-4 text-white" />;
      case "study_session":
        return <Clock className="h-4 w-4 text-white" />;
      default:
        return <Clock className="h-4 w-4 text-white" />;
    }
  };

  const getActivityBgColor = (type: string) => {
    switch (type) {
      case "process_fitness":
        return "bg-amber-500";
      case "yoga":
        return "bg-cyan-500";
      case "study_session":
        return "bg-primary";
      default:
        return "bg-gray-500";
    }
  };

  const getActivityName = (activity: any) => {
    switch (activity.activityType) {
      case "process_fitness":
        return "Process Fitness";
      case "yoga":
        return "Yoga Session";
      case "study_session":
        return "Study Session";
      default:
        return "Activity";
    }
  };

  const getActivityTime = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch (e) {
      return "Recently";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "in_progress":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="px-0 pb-0">
        {isLoading ? (
          <div className="space-y-4 px-6 pb-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : activities.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-neutral-500">No recent activities</p>
          </div>
        ) : (
          <>
            <div className="border-y border-neutral-200">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Activity</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Type</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider hidden md:table-cell">Time</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {activities.map((activity: any, index: number) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`flex-shrink-0 h-8 w-8 rounded-full ${getActivityBgColor(activity.activityType)} flex items-center justify-center`}>
                            {getActivityIcon(activity.activityType)}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              Activity {activity.activityId}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-neutral-500">{getActivityName(activity)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap hidden md:table-cell">
                        <div className="text-sm text-neutral-500">{getActivityTime(activity.completedAt)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge variant="secondary" className={getStatusColor(activity.status)}>
                          {activity.status === "completed" ? "Completed" : "In Progress"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="bg-neutral-50 px-6 py-4">
              <Link href="/progress-analytics">
                <a className="text-primary hover:text-primary/80 font-medium text-sm flex items-center justify-center">
                  View All Activity
                  <ChevronRight className="ml-1 h-4 w-4" />
                </a>
              </Link>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
