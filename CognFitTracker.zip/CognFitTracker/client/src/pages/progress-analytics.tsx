import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/ui/sidebar";
import { MobileHeader } from "@/components/ui/mobile-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell 
} from "recharts";
import { startOfMonth, subMonths, format, eachDayOfInterval, subDays } from "date-fns";

export default function ProgressAnalytics() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });
  
  const { data: studySessions, isLoading: sessionsLoading } = useQuery({
    queryKey: ["/api/study-sessions"],
  });
  
  const { data: activityCompletions, isLoading: completionsLoading } = useQuery({
    queryKey: ["/api/activity-completions"],
  });
  
  // Generate a month's worth of study data for demo
  const generateMonthlyStudyData = () => {
    if (!studySessions) return [];
    
    const currentDate = new Date();
    const startDate = startOfMonth(subMonths(currentDate, 1));
    const endDate = currentDate;
    
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    return days.map(day => {
      const dayFormatted = format(day, "yyyy-MM-dd");
      const sessionsForDay = studySessions.filter((session: any) => {
        const sessionDate = new Date(session.date);
        return format(sessionDate, "yyyy-MM-dd") === dayFormatted;
      });
      
      const totalMinutes = sessionsForDay.reduce((total: number, session: any) => {
        return total + session.duration;
      }, 0);
      
      return {
        date: format(day, "MMM dd"),
        minutes: totalMinutes,
        hours: parseFloat((totalMinutes / 60).toFixed(1))
      };
    });
  };
  
  // Generate activity type distribution data
  const generateActivityTypeData = () => {
    if (!activityCompletions) return [];
    
    const yogaCount = activityCompletions.filter((completion: any) => 
      completion.activityType === "yoga"
    ).length;
    
    const processFitnessCount = activityCompletions.filter((completion: any) => 
      completion.activityType === "process_fitness"
    ).length;
    
    const studySessionCount = activityCompletions.filter((completion: any) => 
      completion.activityType === "study_session"
    ).length;
    
    return [
      { name: "Yoga", value: yogaCount },
      { name: "Process Fitness", value: processFitnessCount },
      { name: "Study Session", value: studySessionCount }
    ];
  };
  
  // Generate focus score trend data
  const generateFocusScoreData = () => {
    if (!activityCompletions) return [];
    
    // Get completions with focus scores from the last 7 days
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), i);
      return {
        date: format(date, "MMM dd"),
        formattedDate: format(date, "yyyy-MM-dd")
      };
    }).reverse();
    
    return last7Days.map(day => {
      const completionsForDay = activityCompletions.filter((completion: any) => {
        const completionDate = new Date(completion.completedAt);
        return format(completionDate, "yyyy-MM-dd") === day.formattedDate;
      });
      
      const focusScores = completionsForDay
        .filter((completion: any) => completion.focusScore !== null && completion.focusScore !== undefined)
        .map((completion: any) => completion.focusScore);
      
      const averageFocusScore = focusScores.length > 0
        ? focusScores.reduce((sum: number, score: number) => sum + score, 0) / focusScores.length
        : 0;
      
      return {
        date: day.date,
        focusScore: parseFloat(averageFocusScore.toFixed(1))
      };
    });
  };
  
  const monthlyStudyData = generateMonthlyStudyData();
  const activityTypeData = generateActivityTypeData();
  const focusScoreData = generateFocusScoreData();
  
  // Custom colors for charts
  const COLORS = ['#3f51b5', '#ff5722', '#00bcd4', '#4caf50'];
  
  const isLoading = statsLoading || sessionsLoading || completionsLoading;

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader title="Progress Analytics" />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pt-8 pb-12 md:py-12 px-4 md:px-8 md:ml-64">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Progress Analytics</h2>
              <p className="text-neutral-500 mt-1">
                Track your academic progress and performance over time
              </p>
            </div>
            
            <Tabs defaultValue="overview">
              <TabsList className="mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="study">Study Time</TabsTrigger>
                <TabsTrigger value="focus">Focus Score</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Weekly Summary Card */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Weekly Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <Skeleton className="h-64" />
                      ) : (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-white rounded-lg p-4 border">
                            <p className="text-neutral-500 text-sm">Study Time</p>
                            <p className="text-2xl font-bold text-gray-900 mt-1">{stats?.weeklyStudyHours}</p>
                          </div>
                          <div className="bg-white rounded-lg p-4 border">
                            <p className="text-neutral-500 text-sm">Yoga Sessions</p>
                            <p className="text-2xl font-bold text-gray-900 mt-1">{stats?.yogaCompleted}</p>
                          </div>
                          <div className="bg-white rounded-lg p-4 border">
                            <p className="text-neutral-500 text-sm">Process Fitness</p>
                            <p className="text-2xl font-bold text-gray-900 mt-1">{stats?.processCompleted}</p>
                          </div>
                          <div className="bg-white rounded-lg p-4 border">
                            <p className="text-neutral-500 text-sm">Focus Score</p>
                            <p className="text-2xl font-bold text-gray-900 mt-1">{stats?.focusScore}</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  {/* Activity Distribution Card */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Activity Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <Skeleton className="h-64" />
                      ) : (
                        <ResponsiveContainer width="100%" height={250}>
                          <PieChart>
                            <Pie
                              data={activityTypeData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            >
                              {activityTypeData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      )}
                    </CardContent>
                  </Card>
                  
                  {/* Daily Study Chart */}
                  <Card className="md:col-span-2">
                    <CardHeader>
                      <CardTitle>Daily Study Time</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <Skeleton className="h-64" />
                      ) : (
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart data={stats?.dailyStudyData || []}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="day" />
                            <YAxis unit="min" />
                            <Tooltip formatter={(value) => [`${value} min`, 'Study Time']} />
                            <Legend />
                            <Bar dataKey="minutes" name="Study Time (minutes)" fill="#3f51b5" />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="study">
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Study Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <Skeleton className="h-96" />
                    ) : (
                      <ResponsiveContainer width="100%" height={400}>
                        <LineChart data={monthlyStudyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis yAxisId="left" unit="min" />
                          <YAxis yAxisId="right" orientation="right" unit="h" />
                          <Tooltip />
                          <Legend />
                          <Line
                            yAxisId="left"
                            type="monotone"
                            dataKey="minutes"
                            stroke="#3f51b5"
                            name="Study Minutes"
                            activeDot={{ r: 8 }}
                          />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="hours"
                            stroke="#ff5722"
                            name="Study Hours"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="focus">
                <Card>
                  <CardHeader>
                    <CardTitle>Focus Score Trend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <Skeleton className="h-96" />
                    ) : (
                      <ResponsiveContainer width="100%" height={400}>
                        <LineChart data={focusScoreData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis domain={[0, 10]} />
                          <Tooltip />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="focusScore"
                            stroke="#00bcd4"
                            name="Focus Score"
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
