import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/ui/sidebar";
import { MobileHeader } from "@/components/ui/mobile-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Clock, Check, Award } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function YogaSessions() {
  const [selectedSession, setSelectedSession] = useState<any>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { data: sessions, isLoading } = useQuery({
    queryKey: ["/api/yoga-sessions"],
  });
  
  const { data: completions, isLoading: completionsLoading } = useQuery({
    queryKey: ["/api/activity-completions"],
  });
  
  const completeSession = async (sessionId: number) => {
    try {
      await apiRequest("POST", "/api/activity-completions", {
        activityType: "yoga",
        activityId: sessionId,
        status: "completed",
        focusScore: 8 // For demo purposes, we're using a fixed focus score
      });
      
      toast({
        title: "Session completed",
        description: "Great job! You've completed a yoga session",
      });
      
      // Close the dialog
      setSelectedSession(null);
      
      // Invalidate the activity completions query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/activity-completions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem recording your session",
        variant: "destructive",
      });
    }
  };
  
  const isSessionCompleted = (sessionId: number) => {
    if (!completions) return false;
    
    return completions.some(
      (completion: any) => 
        completion.activityId === sessionId && 
        completion.activityType === "yoga" &&
        completion.status === "completed"
    );
  };
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-blue-100 text-blue-800";
      case "advanced":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader title="Yoga Sessions" />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pt-8 pb-12 md:py-12 px-4 md:px-8 md:ml-64">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Yoga Sessions</h2>
              <p className="text-neutral-500 mt-1">
                Pre-recorded yoga sessions designed for students to improve focus and reduce stress
              </p>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(5)].map((_, index) => (
                  <Skeleton key={index} className="h-64" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sessions?.map((session: any) => (
                  <Card key={session.id} className="overflow-hidden transition-all duration-200 hover:shadow-md">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <Badge 
                          className={getDifficultyColor(session.difficulty)}
                          variant="secondary"
                        >
                          {session.difficulty.charAt(0).toUpperCase() + session.difficulty.slice(1)}
                        </Badge>
                        <div className="flex items-center text-neutral-500">
                          <Clock className="h-4 w-4 mr-1" />
                          <span className="text-sm">{session.duration} min</span>
                        </div>
                      </div>
                      <CardTitle className="text-xl mt-2">{session.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {session.description}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="pb-2">
                      <div className="relative rounded-md overflow-hidden bg-black h-40">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="bg-white hover:bg-white/90 h-12 w-12 rounded-full"
                            onClick={() => setSelectedSession(session)}
                          >
                            <Play className="h-6 w-6 text-primary" />
                          </Button>
                        </div>
                        {/* YouTube thumbnail placeholder */}
                        <div className="bg-gray-800 h-full opacity-50"></div>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="pt-0">
                      {isSessionCompleted(session.id) ? (
                        <div className="w-full text-center text-sm text-green-600 font-medium flex items-center justify-center">
                          <Check className="h-4 w-4 mr-1" />
                          Completed
                        </div>
                      ) : (
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => setSelectedSession(session)}
                        >
                          Start Session
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </main>
        
        {/* Video Dialog */}
        <Dialog 
          open={!!selectedSession} 
          onOpenChange={(open) => !open && setSelectedSession(null)}
        >
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedSession?.title}</DialogTitle>
              <DialogDescription>
                {selectedSession?.duration} min • {selectedSession?.difficulty}
              </DialogDescription>
            </DialogHeader>
            
            <div className="relative aspect-video rounded-md overflow-hidden">
              {selectedSession?.videoUrl && (
                <iframe
                  width="100%"
                  height="100%"
                  src={selectedSession.videoUrl}
                  title={selectedSession.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="absolute inset-0"
                ></iframe>
              )}
            </div>
            
            <div className="flex justify-end mt-4">
              <Button onClick={() => completeSession(selectedSession.id)}>
                <Award className="h-4 w-4 mr-2" />
                Mark as Completed
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
