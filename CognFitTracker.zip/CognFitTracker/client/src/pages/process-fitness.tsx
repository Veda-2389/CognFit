import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/ui/sidebar";
import { MobileHeader } from "@/components/ui/mobile-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Timer, Clock, TimerOff, ArrowRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function ProcessFitness() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/process-fitness"],
  });
  
  const { data: completions, isLoading: completionsLoading } = useQuery({
    queryKey: ["/api/activity-completions"],
  });
  
  const startActivity = async (activityId: number) => {
    try {
      await apiRequest("POST", "/api/activity-completions", {
        activityType: "process_fitness",
        activityId,
        status: "in_progress"
      });
      
      toast({
        title: "Activity started",
        description: "You've started a new process fitness activity",
      });
      
      // Invalidate the activity completions query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/activity-completions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem starting the activity",
        variant: "destructive",
      });
    }
  };
  
  const completeActivity = async (activityId: number) => {
    try {
      await apiRequest("POST", "/api/activity-completions", {
        activityType: "process_fitness",
        activityId,
        status: "completed",
        focusScore: 8 // For demo purposes, we're using a fixed focus score
      });
      
      toast({
        title: "Activity completed",
        description: "Great job! You've completed a process fitness activity",
      });
      
      // Invalidate the activity completions query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/activity-completions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem completing the activity",
        variant: "destructive",
      });
    }
  };
  
  const isActivityCompleted = (activityId: number) => {
    if (!completions) return false;
    
    return completions.some(
      (completion: any) => 
        completion.activityId === activityId && 
        completion.activityType === "process_fitness" &&
        completion.status === "completed"
    );
  };
  
  const isActivityInProgress = (activityId: number) => {
    if (!completions) return false;
    
    return completions.some(
      (completion: any) => 
        completion.activityId === activityId && 
        completion.activityType === "process_fitness" &&
        completion.status === "in_progress"
    );
  };

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader title="Process Fitness" />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pt-8 pb-12 md:py-12 px-4 md:px-8 md:ml-64">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Process Fitness</h2>
              <p className="text-neutral-500 mt-1">
                Techniques and exercises to improve your study methods and cognitive processes
              </p>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, index) => (
                  <Skeleton key={index} className="h-64" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activities?.map((activity: any) => (
                  <Card key={activity.id} className="overflow-hidden transition-all duration-200 hover:shadow-md">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <Badge variant="outline">{activity.category}</Badge>
                        <div className="flex items-center text-neutral-500">
                          <Clock className="h-4 w-4 mr-1" />
                          <span className="text-sm">{activity.duration} min</span>
                        </div>
                      </div>
                      <CardTitle className="text-xl mt-2">{activity.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {activity.description}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      {activity.imageUrl && (
                        <div className="h-20 flex items-center justify-center">
                          <img 
                            src={activity.imageUrl} 
                            alt={activity.title} 
                            className="h-16 w-16 object-contain"
                          />
                        </div>
                      )}
                    </CardContent>
                    
                    <CardFooter>
                      {isActivityCompleted(activity.id) ? (
                        <Button className="w-full" variant="outline" disabled>
                          <TimerOff className="h-4 w-4 mr-2" />
                          Completed
                        </Button>
                      ) : isActivityInProgress(activity.id) ? (
                        <Button 
                          className="w-full" 
                          onClick={() => completeActivity(activity.id)}
                        >
                          <Timer className="h-4 w-4 mr-2" />
                          Mark as Completed
                        </Button>
                      ) : (
                        <Button 
                          className="w-full" 
                          variant="outline"
                          onClick={() => startActivity(activity.id)}
                        >
                          <ArrowRight className="h-4 w-4 mr-2" />
                          Start Activity
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
