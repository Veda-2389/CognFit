import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/ui/sidebar";
import { MobileHeader } from "@/components/ui/mobile-header";
import { ProgressCard } from "@/components/dashboard/progress-card";
import { StudyTracker } from "@/components/dashboard/study-tracker";
import { RecommendedActivities } from "@/components/dashboard/recommended-activities";
import { RecentActivity } from "@/components/dashboard/recent-activity";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const currentDate = format(new Date(), "EEEE, MMMM d, yyyy");

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader title="Dashboard" />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pt-8 pb-12 md:py-12 px-4 md:px-8 md:ml-64">
          <div className="max-w-7xl mx-auto">
            {/* Welcome & Date */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900">
                Welcome back, {user?.fullName || 'there'}!
              </h2>
              <p className="text-neutral-500 mt-1">{currentDate}</p>
            </div>
            
            {/* Progress Overview Cards */}
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Your Progress</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {statsLoading ? (
                  <>
                    <Skeleton className="h-32" />
                    <Skeleton className="h-32" />
                    <Skeleton className="h-32" />
                    <Skeleton className="h-32" />
                  </>
                ) : (
                  <>
                    <ProgressCard
                      title="Weekly Study Time"
                      value={stats?.weeklyStudyHours || "0 hrs"}
                      trend={stats?.weeklyStudyIncrease || "0% from last week"}
                      trendType={parseInt(stats?.weeklyStudyIncrease) >= 0 ? "positive" : "negative"}
                      icon="schedule"
                      color="primary"
                    />
                    
                    <ProgressCard
                      title="Process Fitness"
                      value={stats?.processCompleted || "0/0"}
                      trend={stats?.processPercentage || "0% completed"}
                      trendType="neutral"
                      icon="fitness_center"
                      color="secondary"
                    />
                    
                    <ProgressCard
                      title="Yoga Sessions"
                      value={stats?.yogaCompleted || "0"}
                      trend={stats?.yogaIncrease || "0 more than last week"}
                      trendType="positive"
                      icon="self_improvement"
                      color="accent"
                    />
                    
                    <ProgressCard
                      title="Focus Score"
                      value={stats?.focusScore || "0/10"}
                      trend={stats?.focusImprovement || "Neutral"}
                      trendType="positive"
                      icon="psychology"
                      color="primary"
                    />
                  </>
                )}
              </div>
            </div>
            
            {/* Study Tracker & Recommended */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Weekly Study Tracker */}
              <div className="lg:col-span-2">
                <StudyTracker dailyData={stats?.dailyStudyData || []} isLoading={statsLoading} />
              </div>
              
              {/* Recommended Activities */}
              <div className="lg:col-span-1">
                <RecommendedActivities isLoading={statsLoading} />
              </div>
            </div>
            
            {/* Recent Activity */}
            <div className="mt-8">
              <RecentActivity activities={stats?.recentActivity || []} isLoading={statsLoading} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
